# adapter-demo-react

This is the demo of `@tronweb3/tronwallet-adapter-react-ui`. Please refer the introduction [here](https://github.com/tronprotocol/tronwallet-adapter/blob/main/packages/react/react-ui/README.md).

## Start

```bash
pnpm install
pnpm dev
```
